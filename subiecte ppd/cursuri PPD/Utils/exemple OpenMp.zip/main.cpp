#include <iostream>
#include "omp.h"
#include "test_fibonacci.h"
#include "LinkedList.h"
#include "test_hello.h"
#include "test_firstprivate.h"
#include "test_reduction.h"
#include "test_tasks_sections.h"

using namespace std;

int fib(int n);
int main() {
    cout << "Hello, World!" << endl;

//    int nthreads, tid;
//    omp_set_num_threads(4);

//   if (!test_hello()) cout <<"test hello ok"<<endl;
//
//  if (!test_private()) cout <<"test firstprivate ok"<<endl;

// for, and reduction
//    cout << endl << "test reduction " << endl;
//    int a[1024], b[1024], c[1024];int s=0, n=1024, d=0;
//    for (int i = 0; i < n; ++i) {
//        a[i] = i + 1 ;
//        b[i] = i + 1;
//        s+=a[i];
//        d=d+a[i]*b[i];
//    }

//    printf(" suma de 2 vectori");test_sum_vector(a, b, c, n);
//    for (int i = 0; i < n; ++i)  printf(" %d", c[i]);
//
//     printf("   Sum Vector = %d verif secv= %d\n", test_vector_sum(a, n), s);
//    for (int i = 0; i < n; ++i) printf("c[%d] =  %d\n", i, c[i]);
//    printf("   Sum = %d  %d\n",test_sum(a, n), s);
//    printf("   Dot product = %d  %d\n",test_vector_dot(a, b ,n)  , d  );

    // test simple tasks execution
//    if (!test_task()) cout<<endl<<"test tasks OK"<<endl;


    //compute fibonacci
//    cout << "fib(10)=" << test_fibo(10) << endl << "test tasks" << endl;

//    LinkedL list;
//    list.insert(5);list.insert(4);list.insert(6);
//#pragma omp parallel
//    {
//    #pragma omp sections
//    {
//        #pragma omp section
//                { for (int i = 1; i < 100; i++)
//                        list.insert(5*i);
//                }
//        #pragma omp section
//                { for (int i = 1; i < 100; i++) list.insert(40*i); }
//        #pragma omp section
//                { for (int i = 1; i < 100; i++) list.insert(6*i); }
//    }
//
//    #pragma omp for schedule(static )
//    for (int i = 0; i < 15; i++) {
//
//        list.insert(100-i);
//    }
//}
//    list.iterate_print();


// for +tasks
//
//        omp_lock_t lock;
//        omp_init_lock(&lock);
//#pragma omp parallel
//        {
//            int i;
//#pragma omp for
//            for (i = 0; i < 100; i++) {
//#pragma omp task
//                {
//// lock is shared by default in the task
//                    omp_set_lock(&lock);
//                    // Capture data for the following task
//#pragma omp task
//// Task Scheduling Point 1
//                    { /* do work here */ }
//                    omp_unset_lock(&lock);
//                }
//            }
//        }
//        omp_destroy_lock(&lock);


}//end -> main





