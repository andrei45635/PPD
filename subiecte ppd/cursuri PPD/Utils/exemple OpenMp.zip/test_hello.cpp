//
// Created by Virginia Niculescu on 04/12/2017.
//

#include "test_hello.h"
#include <omp.h>
#include <stdio.h>

int test_hello(){
    int tid, nthreads;
    #pragma omp parallel private(nthreads, tid) num_threads(4)
    {
        /* Obtain thread id */
        tid = omp_get_thread_num();
        printf("Hello World from thread = %d\n", tid);

        /* Only master thread does this */
        if (tid == 0) {
            nthreads = omp_get_num_threads();
            printf("Number of threads = %d\n", nthreads);
        }

    }  /* All threads join master thread and disband */


    return 0;

}