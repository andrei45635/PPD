//
// Created by Virginia Niculescu on 04/12/2017.
//

#ifndef OPENMP_EXAMPLES_TEST_FIBONACCI_H
#define OPENMP_EXAMPLES_TEST_FIBONACCI_H
int test_fibo(int n);
#endif //OPENMP_EXAMPLES_TEST_FIBONACCI_H
