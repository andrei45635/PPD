//
// Created by Virginia Niculescu on 04/12/2017.
//

#ifndef OPENMP_EXAMPLES_LINKEDLIST_H
#define OPENMP_EXAMPLES_LINKEDLIST_H

struct Nod {
    int val;
    Nod *next;
    omp_lock_t lock;
    Nod(int v){
        val = v;
        next = nullptr;
        omp_init_lock(&lock);
    }
    ~Nod(){
        omp_destroy_lock(&lock);
    }
} ;

struct LinkedL{
    Nod* head;
    LinkedL(){
        head = new Nod(-100);
    }
    ~LinkedL();

    void insert( int ival);
    void iterate_print();
};
#endif //OPENMP_EXAMPLES_LINKEDLIST_H
