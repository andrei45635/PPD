//
// Created by Virginia Niculescu on 05/12/2017.
//

#include "test_tasks_sections.h"
#include <omp.h>
#include <stdio.h>
long f(){
    long a=22;
    for(int i=0;i<100000; i++)
        a+=i*2;
    return a;
}
int test_task(){
    printf("first with tasks\n");
#pragma omp parallel
    {
        // a thread pool!!!
    #pragma omp single
        {
            printf("A t=%d %d ", omp_get_thread_num(), f());

            #pragma omp task
            {
                printf("race t=%d %d ", omp_get_thread_num(), f());
            }
            #pragma omp task
            {
                //f();
                printf("car t=%d %d ", omp_get_thread_num(), f());
            }
            #pragma omp taskwait
            printf("final ...t=%d", omp_get_thread_num());
        }
    } // End of parallel region


    //sections!!!

    printf("\n now with sections\n");

#pragma omp parallel
    {
#pragma omp sections
        {
#pragma omp section
            {
                int a= f();
                printf("A t=%d %d ", omp_get_thread_num(),a);
            }
#pragma omp section
            {
                printf("car t=%d %d ", omp_get_thread_num(), f());
            }
#pragma omp section
            {
                f();
                printf("race t=%d %d ", omp_get_thread_num(), f());
            }
#pragma omp section
            {
               printf("t=%d  final ...", omp_get_thread_num());
            }
        }
#pragma omp single
        {
            printf("t=%d  final ...", omp_get_thread_num());
        }
    } // End of parallel region
    return 0;
}