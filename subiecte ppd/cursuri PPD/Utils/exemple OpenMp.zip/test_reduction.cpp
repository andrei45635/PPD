//
// Created by Virginia Niculescu on 04/12/2017.
//

#include "test_reduction.h"
#include <omp.h>
#include <stdio.h>
#include <math.h>


int test_sum(int a[], int n){

    int sum = 0, i=0;
    int chunk =n/10;
#pragma omp parallel for default(none) \
     private(i)  shared( a, n) \
     schedule(static,chunk)\
     reduction(+ :sum)
    for ( i = 0; i < n; i++) {
            sum +=  a[i];
        }
    return sum;
}
/////////////////////////////////////////////////////////////////////
int test_vector_dot(int a[], int b[], int n){

    int dot = 0, i=0;
    int chunk =n/10;
    #pragma omp parallel for default(none) \
     private(i)  shared( a, b, n) \
     schedule(static,chunk)\
     reduction(+ :dot)
    for ( i = 0; i < n; i++) {
         dot = dot + a[i]*b[i];
    }
    return dot;
}
/////////////////////////////////////////////////////////////////////
int test_vector_sum(int a[], int n){
    int sum= 0;
    int chunk =2;
    int p = omp_get_num_threads(), id;
    int sum_local = 0;
    printf("????p =%d\n", p);
#pragma omp parallel default(none) private(id, p) firstprivate(chunk, sum_local) shared(sum, a, n)
    {

    #pragma omp for schedule(static,chunk)
        for (int i = 0; i < n; i++) {
            sum_local += a[i];
        }
        printf("sum local =%d\n", sum_local);

        #pragma omp critical
        {
            sum += sum_local;
            printf("sum  =%d\n", sum);
        }
    }
    return sum;
}
/////////////////////////////////////////////////////////////////////
int test_vector_sum_tree(int a[], int n)
{
    int sum= 0;
    int chunk =2;
    int p, id;
    int* sum_local = new int[n];
#pragma omp parallel  default(none) private(id,  p) firstprivate(chunk) shared(  sum, a, sum_local, n)
    {
        p = omp_get_num_threads();
        id = omp_get_thread_num();
        sum_local[id]=0;

      //  printf("p=%d, id=%d, sum_local[id]=%d\n", p, id, sum_local[id]);
    #pragma omp for
        //schedule(static,chunk)
        for (int i = 0; i < n; i++) {
            sum_local[id] += a[i];
        }
       // printf("sum local =%d\n", sum_local[id]);

    int levels = log2(p);
    for (int k=0; k<levels; k++){
        if (id%(1<<(k+1))==0)
            sum_local[id] += sum_local[id+(1<<k)];
        #pragma omp barrier
        }
    }
    return sum_local[0];
}
/////////////////////////////////////////////////////////////////////
int test_sum_vector(int a[], int b[], int c[], int n)
{
     int i=0;
    int chunk =n/10;
#pragma omp parallel  default(none) \
     private(i)  shared( a, b, c, n)
    {
        #pragma omp for schedule(static,chunk)
        for (i = 0; i < n; i++) {
            c[i] = a[i] + b[i];
        }
    }
return 0;
}
/////////////////////////////////////////////////////////////////////
//from 4.0 version - operator for reduction
int mymax(int r,int n) {
// r is the already reduced value
// n is the new value
    int m;
    if (n>r) {
        m = n;
    } else {
        m = r;
    }
    return m;
}
int test_op_sum(int a[], int b[], int n) {
    int m = 0;
#pragma omp declare reduction  (myOperator:int:omp_out=mymax(omp_out,omp_in))  identity(0)
#pragma omp parallel for reduction(myOperator:m)
    for (int i = 0; i < n; i++) {
 //       m = myOperator(m , a[i]) ;
    }
    return m;
}