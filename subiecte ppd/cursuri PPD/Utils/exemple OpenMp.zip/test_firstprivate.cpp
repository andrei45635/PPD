//
// Created by Virginia Niculescu on 04/12/2017.
//

#include "test_firstprivate.h"
#include <iostream>
#include <omp.h>

using namespace std;

int test_private(){
    cout << endl << "test first private " << endl;
    int i, chunk = 2, indx = 3, tid;
    const int n=11;
    int a[n];
    for (i = 0; i < n; ++i) a[i] = 0;

#pragma omp parallel  shared(chunk,a) private(i,tid) num_threads(3) firstprivate(indx)
//    default(none) daca se foloseste atunci trebuie explicit specificata optiunea de sharing pentru cout
    // pentru cout exista concurenta
//#pragma omp parallel default(none)  shared(n,a, cout) private(i,tid) firstprivate(indx)
    {
        tid = omp_get_thread_num();
//        cout << "indx=" << indx<<endl;// <<"inside TID="<<tid<<endl;
        printf("indx=%d tid=%d\n",indx, tid);
        indx = indx + chunk * tid; //indx set based on tid and chunk
        for (i = indx; i < indx + chunk; i++)
            a[i] = tid + 1;
    } /*-- End of parallel region --*/


    cout << "main thread final indx=" << indx << "i=" << i << endl << "tablou a = "<<endl;
    for (i = 0; i < n; ++i)
        cout << a[i] << " ";

    return 0;
}