//
// Created by Virginia Niculescu on 04/12/2017.
//

#ifndef OPENMP_EXAMPLES_TEST_REDUCTION_H
#define OPENMP_EXAMPLES_TEST_REDUCTION_H
int test_sum(int a[], int n);
int test_op_sum(int a[], int n);
int test_vector_dot(int a[], int b[], int n);
int test_vector_sum(int a[], int n);
int test_vector_sum_tree(int a[], int n);
int test_sum_vector(int a[], int b[], int c[],  int n);
#endif //OPENMP_EXAMPLES_TEST_REDUCTION_H
