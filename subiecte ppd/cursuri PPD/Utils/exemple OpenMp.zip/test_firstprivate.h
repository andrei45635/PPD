//
// Created by Virginia Niculescu on 04/12/2017.
//

#ifndef OPENMP_EXAMPLES_TEST_FIRSTPRIVATE_H
#define OPENMP_EXAMPLES_TEST_FIRSTPRIVATE_H
int test_private();
#endif //OPENMP_EXAMPLES_TEST_FIRSTPRIVATE_H
