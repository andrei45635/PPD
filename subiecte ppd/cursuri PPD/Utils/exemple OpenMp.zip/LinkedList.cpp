//
// Created by Virginia Niculescu on 04/12/2017.
//
#include "omp.h"
#include "LinkedList.h"
#include <iostream>

using namespace std;

//find the insert location
void LinkedL::insert( int ival) {
    Nod* new_nod = new Nod(ival);
    Nod * ptr = head->next;
    Nod * prev = head;

/* Lock the elements that we are considering */
    omp_set_lock(&prev->lock);
    while (ptr!= nullptr) {
        omp_set_lock(&ptr->lock);
        if (ptr->val >= ival ) break;
        omp_unset_lock(&prev->lock);

        prev = ptr;
        ptr = ptr->next;
    }
 if (ptr == nullptr) {// is added as the last value
     prev->next = new_nod;
     omp_unset_lock(&prev->lock);
 }
    else {
     //it should be added between prev and ptr
     //they are both locked set!!
     prev->next = new_nod;
     new_nod->next = ptr;
     omp_unset_lock(&prev->lock);
     omp_unset_lock(&ptr->lock);
 }
}


void LinkedL::iterate_print(){
    Nod * ptr = head->next;
    Nod * prev = head;
    cout<<"The list is"<<endl;
/* Lock the elements that we are considering */
    omp_set_lock(&prev->lock);
    while (ptr!= nullptr) {
        omp_set_lock(&ptr->lock);
        cout<<ptr->val<< "  ";
        omp_unset_lock(&prev->lock);
        prev = ptr;
        ptr = ptr->next;
    }
    omp_unset_lock(&prev->lock);
}


LinkedL::~LinkedL(){
    Nod * ptr = head->next;
    omp_destroy_lock(&head->lock);
    delete head;
    cout<<"list destructor:"<<endl;
    while (ptr ) {
        head = ptr;
        ptr = ptr->next;
        delete head;
    }
}