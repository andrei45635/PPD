//
// Created by Virginia Niculescu on 04/12/2017.
//

#ifndef OPENMP_EXAMPLES_TEST_HELLO_H
#define OPENMP_EXAMPLES_TEST_HELLO_H
int test_hello();
#endif //OPENMP_EXAMPLES_TEST_HELLO_H
