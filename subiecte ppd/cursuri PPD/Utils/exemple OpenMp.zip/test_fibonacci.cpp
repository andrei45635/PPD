//
// Created by Virginia Niculescu on 04/12/2017.
//

#include "test_fibonacci.h"
#include <iostream>




int fib(int n) {
    int i, j;
    if (n < 2)
        return n;
    else {

        #pragma omp task shared(i)
                    i = fib(n - 1);
        #pragma omp task shared(j)
                    j = fib(n - 2);
        #pragma omp taskwait
                    return i + j;
                }

}

int test_fibo(int n){
    int result;
    #pragma omp parallel
    {

    #pragma omp single
        {
            result = fib(n);
        }
    }
    return result;
}