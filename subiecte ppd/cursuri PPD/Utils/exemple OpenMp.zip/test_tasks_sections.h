//
// Created by Virginia Niculescu on 05/12/2017.
//

#ifndef OPENMP_EXAMPLES_TEST_TASKS_H
#define OPENMP_EXAMPLES_TEST_TASKS_H
int test_task();
#endif //OPENMP_EXAMPLES_TEST_TASKS_H
